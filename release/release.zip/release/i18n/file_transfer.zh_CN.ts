<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="52"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="54"/>
        <source>File Compare</source>
        <translation type="unfinished">文件比较</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="58"/>
        <source>Setting</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="62"/>
        <source>Exit</source>
        <translation type="unfinished">退出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="70"/>
        <source>Other</source>
        <translation type="unfinished">其他</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="72"/>
        <source>GL</source>
        <translation type="unfinished">GL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="76"/>
        <location filename="../src/mainwindow.cpp" line="244"/>
        <source>Changelog</source>
        <translation type="unfinished">更新日志</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="80"/>
        <location filename="../src/mainwindow.cpp" line="337"/>
        <source>Help</source>
        <translation type="unfinished">帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="84"/>
        <source>About</source>
        <translation type="unfinished">关于</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="92"/>
        <source>Image</source>
        <translation type="unfinished">图像</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="94"/>
        <source>Viewer</source>
        <translation type="unfinished">图像查看</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="98"/>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>About compress</source>
        <translation type="unfinished">关于图像压缩的记录</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="121"/>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Warning</source>
        <translation type="unfinished">警告</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="121"/>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>Some transfer task is running!</source>
        <translation type="unfinished">有任务正在执行!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="129"/>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <source>Progressing</source>
        <translation type="unfinished">处理中</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="183"/>
        <source>%1 &lt;br/&gt; Using %2</source>
        <translation type="unfinished">%1 &lt;br/&gt; 耗时 %2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>About application</source>
        <translation type="unfinished">关于程序</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="208"/>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <location filename="../src/mainwindow.cpp" line="223"/>
        <location filename="../src/mainwindow.cpp" line="233"/>
        <source>Cancel</source>
        <translation type="unfinished">取消</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="213"/>
        <source>Copy</source>
        <translation type="unfinished">复制</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <source>Check</source>
        <translation type="unfinished">效验</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <location filename="../src/mainwindow.cpp" line="238"/>
        <source>Done</source>
        <translation type="unfinished">完成</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="337"/>
        <source>Drag file and drop to file list window to transfer file.</source>
        <translation type="unfinished">拖拽文件到文件列表窗口进行文件传输</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="351"/>
        <source>_IMAGE_COMPRESS_LOG</source>
        <translation type="unfinished">关于图像文件的压缩的测试: &lt;br/&gt; 1, 对于图像文件的单文件压缩发现, 如同视频媒体文件一样, 一般的图像文件都是已经经过压缩的. 我使用哈夫曼编码压缩, 压缩结果和原文件大小相差无几. &lt;br/&gt; 2, 使用 &apos;像素索引 - 颜色表&apos; 这种方式保存图像文件:    首先, 将jpg图像数据转换为上述的数据布局保存, 图像大小比原来大若干倍, 即使再用哈夫曼编码压缩, 还是比原图像文件大几倍, 所以不具备压缩文件大小的效果. &lt;br/&gt;     其次, 数据布局按 &apos;像素索引 - 颜色表&apos; 排列, 时间消耗与图像尺寸是呈指数增长的, 且时间很长. &lt;br/&gt; 我得出的结论是, 一般常用的图像文件都是经过他们自己的方法压缩过. 在不能压缩图像质量的前提下, 以我的认知来看很难再对其大小进行压缩.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/karin_std.cpp" line="196"/>
        <source>hour</source>
        <translation type="unfinished">时</translation>
    </message>
    <message>
        <location filename="../src/karin_std.cpp" line="203"/>
        <source>minute</source>
        <translation type="unfinished">分</translation>
    </message>
    <message>
        <location filename="../src/karin_std.cpp" line="210"/>
        <source>second</source>
        <translation type="unfinished">秒</translation>
    </message>
    <message>
        <location filename="../src/karin_ut.cpp" line="55"/>
        <source>Version</source>
        <translation type="unfinished">版本</translation>
    </message>
    <message>
        <location filename="../src/karin_ut.cpp" line="56"/>
        <source>Dev</source>
        <translation type="unfinished">Dev</translation>
    </message>
    <message>
        <location filename="../src/karin_ut.cpp" line="57"/>
        <source>Release</source>
        <translation type="unfinished">发布时间</translation>
    </message>
    <message>
        <location filename="../src/karin_ut.cpp" line="58"/>
        <source>Code</source>
        <translation type="unfinished">Code</translation>
    </message>
    <message>
        <location filename="../src/karin_ut.cpp" line="59"/>
        <source>Source</source>
        <translation type="unfinished">源码</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="13"/>
        <source>Scan</source>
        <translation type="unfinished">扫描</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="14"/>
        <source>Mkdir</source>
        <translation type="unfinished">创建路径</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="15"/>
        <source>Transfer</source>
        <translation type="unfinished">传输</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="16"/>
        <source>Check</source>
        <translation type="unfinished">效验</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="20"/>
        <source>ready</source>
        <translation type="unfinished">准备</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="21"/>
        <source>start</source>
        <translation type="unfinished">开始</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="22"/>
        <source>pause</source>
        <translation type="unfinished">暂停</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="23"/>
        <source>doing</source>
        <translation type="unfinished">进行中</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="24"/>
        <source>success</source>
        <translation type="unfinished">成功</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="25"/>
        <source>fail</source>
        <translation type="unfinished">失败</translation>
    </message>
</context>
<context>
    <name>karin_FSModel</name>
    <message>
        <location filename="../src/karin_fsmodel.cpp" line="142"/>
        <source>directory</source>
        <translation type="unfinished">文件夹</translation>
    </message>
</context>
<context>
    <name>karin_FileCmpDialog</name>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="32"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="36"/>
        <source>File Compare</source>
        <translation type="unfinished">文件比较</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="70"/>
        <source>Open first file</source>
        <translation type="unfinished">选择文件A</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="83"/>
        <source>Open second file</source>
        <translation type="unfinished">选择文件B</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="116"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="117"/>
        <source>Equal</source>
        <translation type="unfinished">相同</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="116"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="117"/>
        <source>Not equal</source>
        <translation type="unfinished">不相同</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="119"/>
        <source>File is same</source>
        <translation type="unfinished">文件相同</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="119"/>
        <source>File is not same</source>
        <translation type="unfinished">文件不相同</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="129"/>
        <source>Comparing...</source>
        <translation type="unfinished">比较中...</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="81"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="138"/>
        <source>Compare</source>
        <translation type="unfinished">比较</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="154"/>
        <source>File %1 %2 %3: %4</source>
        <translation type="unfinished">文件 %1 %2 %3: %4</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="47"/>
        <source>Choose first file </source>
        <translation type="unfinished">选择文件1</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="61"/>
        <source>Choose second file</source>
        <translation type="unfinished">选择文件2</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="114"/>
        <source>Compare result</source>
        <translation type="unfinished">比较结果</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="179"/>
        <source>File 1</source>
        <translation type="unfinished">文件1</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="187"/>
        <source>File 2</source>
        <translation type="unfinished">文件2</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="195"/>
        <source>Result</source>
        <translation type="unfinished">结果</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="203"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="154"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="172"/>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.ui" line="211"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="154"/>
        <location filename="../src/karin_filecmpdialog.cpp" line="172"/>
        <source>SHA1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="172"/>
        <source>Info</source>
        <translation type="unfinished">信息</translation>
    </message>
    <message>
        <location filename="../src/karin_filecmpdialog.cpp" line="172"/>
        <source>File %1 sum has copy to clipboard</source>
        <translation type="unfinished">文件 %1 效验码已经复制到粘贴板</translation>
    </message>
</context>
<context>
    <name>karin_FileEngine</name>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="116"/>
        <source>Ready</source>
        <translation type="unfinished">空闲</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="117"/>
        <source>Prepare</source>
        <translation type="unfinished">准备</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="118"/>
        <source>Scanning files and directories</source>
        <translation type="unfinished">扫描文件夹</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="119"/>
        <source>Scanning finished</source>
        <translation type="unfinished">扫描完成</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="120"/>
        <source>Create directories</source>
        <translation type="unfinished">创建文件夹</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="121"/>
        <source>Copy files to dest</source>
        <translation type="unfinished">复制文件到目标</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="122"/>
        <source>Copy files finished</source>
        <translation type="unfinished">复制文件完成</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="123"/>
        <source>MD5 checking</source>
        <translation type="unfinished">MD5效验</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="124"/>
        <source>Operation done</source>
        <translation type="unfinished">操作完成</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="176"/>
        <source>Scan %1: %2</source>
        <translation type="unfinished">扫描 %1: %2</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="218"/>
        <source>Scanning: %1 files, %2 dirs &lt;br/&gt; %3 size: %4(%5 bytes)</source>
        <translation type="unfinished">扫描中: %1 文件, %2 文件夹 &lt;br/&gt; %3 大小: %4(%5 字节)</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="256"/>
        <source>Find %1 files, %2 dirs &lt;br/&gt; Total size: %3(%4 bytes)</source>
        <translation type="unfinished">发现 %1 文件, %2 文件夹 &lt;br/&gt; 总大小: %3(%4 字节)</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="291"/>
        <source>files</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="299"/>
        <source>Mkdir %1: count : %2</source>
        <translation type="unfinished">创建路径 %1: 数量 : %2</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="330"/>
        <source>Make directory count: %1</source>
        <translation type="unfinished">创建文件夹数量: %1</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="362"/>
        <source>Total make directorys %1 success, %2 fail</source>
        <translation type="unfinished">全部创建文件夹 %1 成功, %2 失败</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="402"/>
        <location filename="../src/karin_fileengine.cpp" line="542"/>
        <source>Transfer %1: count : %2</source>
        <translation type="unfinished">传输 %1: 数量 : %2</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="459"/>
        <source>Transfer count: %1 &lt;br/&gt; Size: %2(%3 bytes)</source>
        <translation type="unfinished">传输数量: %1 &lt;br/&gt; 大小: %2(%3 字节)</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="495"/>
        <source>Total transfer: %1 success, %2 fail &lt;br/&gt; Total size: %3(%4 bytes)</source>
        <translation type="unfinished">全部传输: %1 成功, %2 失败 &lt;br/&gt; 总大小: %3(%4 字节)</translation>
    </message>
    <message>
        <location filename="../src/karin_fileengine.cpp" line="599"/>
        <location filename="../src/karin_fileengine.cpp" line="635"/>
        <source>Check: %1 success, %2 fail</source>
        <translation type="unfinished">效验: %1 成功, %2 失败</translation>
    </message>
</context>
<context>
    <name>karin_FileWindow</name>
    <message>
        <location filename="../src/karin_filewindow.cpp" line="109"/>
        <source>Warning</source>
        <translation type="unfinished">警告</translation>
    </message>
    <message>
        <location filename="../src/karin_filewindow.cpp" line="109"/>
        <source>Desktop service can not open file: %1</source>
        <translation type="unfinished">外部无法打开文件: %1</translation>
    </message>
    <message>
        <location filename="../src/karin_filewindow.cpp" line="115"/>
        <source>Transfer file?</source>
        <translation type="unfinished">传输文件?</translation>
    </message>
    <message>
        <location filename="../src/karin_filewindow.cpp" line="115"/>
        <source>Transfer file to another window?</source>
        <translation type="unfinished">传输文件到另一个窗口</translation>
    </message>
    <message>
        <location filename="../karin_filewindow.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>karin_NLTMainWindow</name>
    <message>
        <location filename="../img_src/qt/karin_nltmainwindow.cpp" line="38"/>
        <source>Image Converter</source>
        <translation type="unfinished">图像查看</translation>
    </message>
    <message>
        <location filename="../img_src/qt/karin_nltmainwindow.cpp" line="46"/>
        <source>Open a image file</source>
        <translation type="unfinished">打开图像文件</translation>
    </message>
    <message>
        <location filename="../img_src/qt/karin_nltmainwindow.cpp" line="66"/>
        <source>Save texture file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../img_src/qt/karin_nltmainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../img_src/qt/karin_nltmainwindow.ui" line="38"/>
        <source>Open file</source>
        <translation type="unfinished">打开文件</translation>
    </message>
</context>
<context>
    <name>karin_ProgressDialog</name>
    <message>
        <location filename="../src/karin_progressdialog.cpp" line="44"/>
        <source>Process Dialog</source>
        <translation type="unfinished">进度对话框</translation>
    </message>
    <message>
        <location filename="../karin_progressdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../karin_progressdialog.ui" line="95"/>
        <source>Log</source>
        <translation type="unfinished">日志</translation>
    </message>
    <message>
        <location filename="../karin_progressdialog.ui" line="167"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>karin_SettingDialog</name>
    <message>
        <location filename="../src/karin_settingdialog.cpp" line="32"/>
        <source>Settings</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="23"/>
        <source>Setting</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="57"/>
        <source>General</source>
        <translation type="unfinished">一般</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="87"/>
        <source>Max working thread</source>
        <translation type="unfinished">最大线程数</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="97"/>
        <source>Enable log</source>
        <translation type="unfinished">启用日志</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="111"/>
        <source>Log level</source>
        <translation type="unfinished">日志级别</translation>
    </message>
    <message>
        <location filename="../karin_settingdialog.ui" line="121"/>
        <source>Open file externally</source>
        <translation type="unfinished">双击在外部打开文件</translation>
    </message>
</context>
</TS>

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="47"/>
        <source>&amp;File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="49"/>
        <source>&amp;Setting</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="53"/>
        <source>&amp;Exit</source>
        <translation type="unfinished">退出</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="60"/>
        <source>&amp;Other</source>
        <translation type="unfinished">其他</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>&amp;GL</source>
        <translation type="unfinished">GL</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="66"/>
        <source>&amp;Changelog</source>
        <translation type="unfinished">更新日志</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="70"/>
        <source>&amp;About</source>
        <translation type="unfinished">关于</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="98"/>
        <source>Progressing</source>
        <translation type="unfinished">处理中</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="117"/>
        <source>About application</source>
        <translation type="unfinished">关于程序</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="130"/>
        <location filename="../mainwindow.cpp" line="135"/>
        <location filename="../mainwindow.cpp" line="140"/>
        <location filename="../mainwindow.cpp" line="145"/>
        <location filename="../mainwindow.cpp" line="155"/>
        <source>Cancel</source>
        <translation type="unfinished">取消</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="135"/>
        <source>Copy</source>
        <translation type="unfinished">复制</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="150"/>
        <source>Check</source>
        <translation type="unfinished">效验</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="150"/>
        <location filename="../mainwindow.cpp" line="160"/>
        <source>Done</source>
        <translation type="unfinished">完成</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <source>Changelog</source>
        <translation type="unfinished">更新日志</translation>
    </message>
    <message>
        <location filename="../ui_mainwindow.h" line="74"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../karin_std.cpp" line="162"/>
        <source>hour</source>
        <translation type="unfinished">时</translation>
    </message>
    <message>
        <location filename="../karin_std.cpp" line="169"/>
        <source>minute</source>
        <translation type="unfinished">分</translation>
    </message>
    <message>
        <location filename="../karin_std.cpp" line="176"/>
        <source>second</source>
        <translation type="unfinished">秒</translation>
    </message>
    <message>
        <location filename="../karin_ut.cpp" line="51"/>
        <source>Version</source>
        <translation type="unfinished">版本</translation>
    </message>
    <message>
        <location filename="../karin_ut.cpp" line="52"/>
        <source>Dev</source>
        <translation type="unfinished">Dev</translation>
    </message>
    <message>
        <location filename="../karin_ut.cpp" line="53"/>
        <source>Release</source>
        <translation type="unfinished">发布时间</translation>
    </message>
    <message>
        <location filename="../karin_ut.cpp" line="54"/>
        <source>Code</source>
        <translation type="unfinished">Code</translation>
    </message>
    <message>
        <location filename="../karin_ut.cpp" line="55"/>
        <source>Source</source>
        <translation type="unfinished">源码</translation>
    </message>
</context>
<context>
    <name>karin_FSModel</name>
    <message>
        <location filename="../karin_fsmodel.cpp" line="142"/>
        <source>directory</source>
        <translation type="unfinished">文件夹</translation>
    </message>
</context>
<context>
    <name>karin_FileEngine</name>
    <message>
        <location filename="../karin_fileengine.cpp" line="100"/>
        <source>Ready</source>
        <translation type="unfinished">空闲</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="101"/>
        <source>Prepare</source>
        <translation type="unfinished">准备</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="102"/>
        <source>Scanning files and directories</source>
        <translation type="unfinished">扫描文件夹</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="103"/>
        <source>Scanning finished</source>
        <translation type="unfinished">扫描完成</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="104"/>
        <source>Create directories</source>
        <translation type="unfinished">创建文件夹</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="105"/>
        <source>Copy files to dest</source>
        <translation type="unfinished">复制文件到目标</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="106"/>
        <source>Copy files finished</source>
        <translation type="unfinished">复制文件完成</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="107"/>
        <source>MD5 checking</source>
        <translation type="unfinished">MD5效验</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="108"/>
        <source>Operation done</source>
        <translation type="unfinished">操作完成</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="197"/>
        <source>Scanning files: %1, dirs %2, size: %3(%4 bytes), using %5 -&gt; %6</source>
        <translation type="unfinished">正在扫描 文件: %1, 文件夹 %2, 大小: %3(%4 字节), 耗时 %5 -&gt; %6</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="234"/>
        <source>Scanning finished: find %1 files, %2 dirs, total size: %3(%4 bytes), using %5</source>
        <translation type="unfinished">扫描完成: 发现 %1 文件, %2 文件夹, 总大小: %3(%4 字节), 耗时 %5</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="304"/>
        <source>Make directory: %1(%2) -&gt; %3, using %4</source>
        <translation type="unfinished">创建文件夹中: %1(%2) -&gt; %3, 耗时 %4</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="330"/>
        <location filename="../karin_fileengine.cpp" line="456"/>
        <location filename="../karin_fileengine.cpp" line="589"/>
        <source>success</source>
        <translation type="unfinished">成功</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="330"/>
        <location filename="../karin_fileengine.cpp" line="456"/>
        <location filename="../karin_fileengine.cpp" line="589"/>
        <source>fail</source>
        <translation type="unfinished">失败</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="335"/>
        <source>Make directorys finished: %1 success, %2 fail, using %3</source>
        <translation type="unfinished">创建文件夹完成: %1 成功, %2 失败, 耗时 %3</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="426"/>
        <source>Transfer file: %1 -&gt; %2, count: %3, size: %4(%5 bytes), using %6</source>
        <translation type="unfinished">传输文件中: %1 -&gt; %2, 数量: %3, 大小: %4(%5 字节), 耗时 %6</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="461"/>
        <source>Transfer finished: %1 success, %2 fail, total size: %3(%4 bytes), using %5</source>
        <translation type="unfinished">传输文件完成: %1 成功, %2 失败, 总大小: %3(%4 字节), 耗时 %5</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="559"/>
        <source>Check file: %1 -&gt; %2, %3 success, %4 fail, using %5</source>
        <translation type="unfinished">效验文件中: %1 -&gt; %2, %3 成功, %4 失败, 耗时 %5</translation>
    </message>
    <message>
        <location filename="../karin_fileengine.cpp" line="594"/>
        <source>Check finished: %1 success, %2 fail, using %3</source>
        <translation type="unfinished">效验文件完成: %1 成功, %2 失败, 耗时 %3</translation>
    </message>
</context>
<context>
    <name>karin_FileWindow</name>
    <message>
        <location filename="../ui_karin_filewindow.h" line="63"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>karin_ProgressDialog</name>
    <message>
        <location filename="../ui_karin_progressdialog.h" line="161"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_karin_progressdialog.h" line="165"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../karin_progressdialog.cpp" line="38"/>
        <source>Process Dialog</source>
        <translation type="unfinished">进度对话框</translation>
    </message>
</context>
<context>
    <name>karin_SettingDialog</name>
    <message>
        <location filename="../karin_settingdialog.cpp" line="31"/>
        <source>Settings</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="143"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="144"/>
        <source>Setting</source>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="145"/>
        <source>General</source>
        <translation type="unfinished">一般</translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="146"/>
        <source>Max working thread</source>
        <translation type="unfinished">最大工作线程</translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="147"/>
        <source>Enable log</source>
        <translation type="unfinished">启用日志</translation>
    </message>
    <message>
        <location filename="../ui_karin_settingdialog.h" line="149"/>
        <source>Log level</source>
        <translation type="unfinished">日志级别</translation>
    </message>
</context>
</TS>
